package game;

public class SafeObstacle extends Obstacle {

	public SafeObstacle(Point[] inShape, Point inPosition, double inRotation) {
		super(inShape, inPosition, inRotation);
	}
	
	

}
