package game;

public class DeadlyObstacle extends Obstacle{

	public DeadlyObstacle(Point[] inShape, Point inPosition, double inRotation) {
		super(inShape, inPosition, inRotation);
	}
	
	

}
