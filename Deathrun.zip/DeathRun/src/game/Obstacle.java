package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Obstacle extends Polygon implements Collidable{
	private int deltaX;
	private int deltaY;

	public Obstacle(Point[] inShape, Point inPosition, double inRotation) {
		super(inShape, inPosition, inRotation);
	}

	public void move() {
        if (position.y < 0 ) deltaY = 2; 
        if (position.x < 0 ) deltaX = 2; 
        if (position.x > 650) deltaX = -2;
        if (position.y > 450) deltaY = -2;
        position.x += deltaX;
        position.y += deltaY;
        
    }
	
	public void rotate(double rotation) {
		this.rotation = rotation;
	}
	
	public void paint(Graphics brush) {
        Point[] pts = getPoints();
        int[] xPts = new int[pts.length];
        int[] yPts = new int[pts.length];
        for (int i = 0; i < pts.length; i++) {
            xPts[i] = (int)pts[i].x;
            yPts[i] = (int)pts[i].y;
        }
        brush.setColor(Color.RED);
        brush.fillPolygon(xPts, yPts, pts.length);
    }

	@Override
	public Rectangle getBounds() {
		
		return null;
	}
}
